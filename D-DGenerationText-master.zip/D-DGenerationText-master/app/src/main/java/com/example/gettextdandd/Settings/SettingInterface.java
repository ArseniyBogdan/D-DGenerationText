package com.example.gettextdandd.Settings;

interface SettingInterface {

    String GenerateFirstSentence();
    String GenerateWeatherDescription();
    String GenerateThirdSentence();
    String GenerateDescriptionLocationWithLSTM();
    String GenerateNPCCharacters();
    String GenerateDescription();

}
